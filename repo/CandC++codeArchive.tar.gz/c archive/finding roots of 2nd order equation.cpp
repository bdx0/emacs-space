#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<math.h>
main()
{
      float a,b,c,x1,x2,delta;
      printf("3 numbers for a,b,c");
      scanf("%f %f %f",&a,&b,&c);
      delta=b*b-4*a*c;
      if(delta<0)
                 {
                      printf("no real roots");
                      }
      else if(delta==0)
           {
                       printf("x1=x2=%f",(-b+sqrt(delta))/(2*a));
                       }
         else
             {
                       x1=(-b+sqrt(delta))/2*a;
                       x2=(-b-sqrt(delta))/2*a;
                       printf("x1=%f x2=%f",x1,x2);
                       }
             getch();
             return 0;
}
                       
