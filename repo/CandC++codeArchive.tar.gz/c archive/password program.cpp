#include<stdio.h>
#include<conio.h>
main()
{
      char password[ ]="Mustafa";
      int i,k=0;
      char A[7];
      
      scanf("%s",A);
      
      for(i=0;A[i]!='\0';i++) 
      {
         if(A[i]==password[i])
         k+=1;
      }
      if(k==7)
      printf("Password is correct");
      else
      printf("Come on man! Try again");
      
      getch();
      return 0;
}
                              
      
