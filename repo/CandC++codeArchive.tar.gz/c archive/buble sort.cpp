#include<stdio.h>
#include<conio.h>
#define size 10

main()


{
      int A[size]={2,4,3,7,1,9,8,6,5,0};
      int k,i,tur,tut;
      
      for(tur=0;tur<size-1;tur++)
      {
      for(i=0;i<size-1;i++)
        if(A[k]>A[k+1]) {
        tut=A[k];
        A[k]=A[k+1];
        A[k+1]=tut;
        }
        } 
        for(i=0;i<=9;i++)
        printf("%d ",A[i]);
        getch();
        }
        
