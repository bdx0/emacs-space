#include<stdio.h>
#include<conio.h>
main()
{
      int number,i,sum,A[5];
      sum=0;
      for(i=0;i<5;i++) {
      scanf("%d",&A[i]);
      sum=sum+A[i]; 
      }
      
      
      printf("Average of the Numbers which you entered:%d",sum/5);
      
      getch();
      return 0;
}
