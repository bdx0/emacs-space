#include<stdio.h>
#include<conio.h>
main ()
{
     int a,b,c,d,i,enbuyuk1,enbuyuk2,enbuyuk3;
     
     scanf("%d %d %d",&a,&b,&d);
     if(a>b){
     enbuyuk1=a;
     enbuyuk2=b; }
     if(a<b) {
     enbuyuk1=b;
     enbuyuk2=a;}
     if(enbuyuk1<d)
     enbuyuk1=d;
     if(d<enbuyuk2)
     {enbuyuk3=d; }
     if(enbuyuk2<d && d<enbuyuk1) {
     enbuyuk3=enbuyuk2;
     enbuyuk2=d; }
     for(i=1;i<=7;i++){
                       scanf("%d",&c);
                       
                       if(c>enbuyuk1){
                                      enbuyuk3=enbuyuk2;
                                      enbuyuk2=enbuyuk1;
                                      enbuyuk1=c; }
                                      if(c<enbuyuk2 && c>enbuyuk3)
                                      {             
                                                    enbuyuk3=c;  }
                                      if(enbuyuk2<c && c<enbuyuk1)
                                      {
                                                     enbuyuk3=enbuyuk2;
                                                    enbuyuk2=c;
                                                    
                                                     }
                                                    }
                                                    printf("enbuyuk1=%d   enbuyuk2=%d    enbuyuk3=%d",enbuyuk1,enbuyuk2,enbuyuk3);
     getch ();
     }
              
