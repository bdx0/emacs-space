#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

main()
{
      int i=0,n;
      int c;
      int number[6];
      unsigned seed;
      printf("enter seed");
      scanf("%u",&seed);
      srand(seed); 
    
      
      for(n=1;n<=6;n++) {
                       /*  printf("enter seed");
                         scanf("%u",&seed);
                         srand(seed); */
                         
                        number[i]=1+rand()%49;
                        if(i==0)
                        printf("%d ",number[i]);
                        else {
                        if(number[i]!=number[i-1])
                        printf("%d ",number[i]); }
                        i+=1;
                        } 
                        getch ();
                        return 0;
                        }
