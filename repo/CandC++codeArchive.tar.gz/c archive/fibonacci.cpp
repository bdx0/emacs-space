#include<stdio.h>
#include<conio.h>
main ()
{
     int a=0,b=1,n,s,c;
     scanf("%d",&n);
     if(n>0) 
     {
     for(s=1;s<=n;s++)
     {
                      c=a+b;
                      a=b;
                      b=c;
                      printf("\n%d",c);
                      } 
     }
                      else
                      printf("pozitif sayi giriniz");
                      getch ();
                      }
                      
                      
                      
                      
     
