#include<stdio.h>
#include<conio.h>
main ()
{
     int sat,sayi,bos,bs,yldz,k;
     for(sat=1;sat<=5;sat++){
                             for(bos=1;bos<=5-sat;bos++)
                             printf(" ");
                             for(sayi=1;sayi<=2*sat-1;sayi++)
                             printf("*");
                             printf("\n");
                             }
     for(k=4;k>=1;k--){
                             for(bs=1;bs<=5-k;bs++)
                             printf(" ");
                             for(yldz=1;yldz<=2*k-1;yldz++)
                             printf("*");
                             printf("\n");
                             }
                             getch ();
                             }
                              
