#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<math.h>
main()
{
      float pozisyon_f;
      int yildiz_poz[120];
      int satir;
      int bos;
      float pi=3.14;
      
      for(satir=1;satir<=20;satir++)
      yildiz_poz[satir]=(satir*(pi/10)+1)*20;
      for(satir=1;satir<=20;satir++) { 
                                      for(bos=1;bos<yildiz_poz[satir];bos++)
                                      printf(" \n");
                                      printf("*\n");
                                      }
                                      getch ();
                                      return 0;
                                      }
