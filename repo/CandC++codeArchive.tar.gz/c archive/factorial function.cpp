#include<stdio.h>
#include<conio.h>
long faktoriyel(long);
main()
{
      int i;
      for(i=1;i<=10;i++)
        printf("%2d!=%ld\n",i,faktoriyel(i));
        getch ();
        return 0;
        }
long faktoriyel(long sayi)
{
     if(sayi<=1)
     return 1;
     else
     return (sayi*faktoriyel(sayi-1));
     
     }
      
