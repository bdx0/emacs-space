#include<stdio.h>
#include<conio.h>
main()
{
      int sales[3][3]={{0}};
      int t,u,i,j,x,gun;
      
      for(gun=1;gun<=2;gun++) {
        printf("%d. gun: \n",gun);
        for(t=0;t<=2;t++)
          for(u=0;u<=2;u++) 
          {
              printf("%d. temsilci i�in %d. urun degerini giriniz:  \n",t+1,u+1);
              scanf("%d",&x);
              sales[u][t]+=x;
              }
              }
      for(i=0;i<=2;i++) {
                        for(j=0;j<=2;j++) {
                        printf("%d\t",sales[i][j]);
                        }
                        printf("\n");
                        }
                        
                        getch ();
                        return 0;
}
              
