#include<stdio.h>
#include<conio.h>
#include<time.h>
#include<stdlib.h>
void kar(int [][13]);
void dagit(const int [][13],const char*[],const char*[]);

int main()
{
    const char *takim[4]={"Kupa","Karo","Sinek","Maca"};
    const char *taraf[13]={"As","iki","uc","dort","bes","alt�","yedi","sekiz","dokuz","on","vale","k�z","papaz"};
    int deste[4][13]={0};
    
    kar(deste);
    dagit(deste,takim,taraf);
    
    getch();
    return 0;
}
void kar(int A[][13])
{
     int satir,sutun,kart;
     
     for(kart=1;kart<=52;kart++) {
     do {
         satir=rand()%4;
         sutun=rand()%13;
         }while(A[satir][sutun]!=0);
         
         A[satir][sutun]=kart;
     }
}
void dagit(int wdeste[][13],const char *wtakim[],const char *wtaraf[])
{
              int kart,satir,sutun;
              
              for(kart=1;kart<=52;kart++) 
                 for(satir=0;satir<=3;satir++)
                   for(sutun=0;sutun<=12;sutun++)
                     if(wdeste[satir][sutun]==kart) {
                       printf("%5sof%-8s%c",
                       wtakim[satir],wtaraf[sutun],
                       kart%2==0?'\n':'\t');
                       }
}
                                          
