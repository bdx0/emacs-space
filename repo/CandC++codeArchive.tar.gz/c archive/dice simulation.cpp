#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<time.h>
main()
{
      int zar,i,rolls,sayac[7]={0};
      
      srand(time(NULL));
      
      for(rolls=1;rolls<=6000;rolls++) {
                                       zar=1+rand()%6;
                                       ++sayac[zar];
                                       }
                                       
                                       printf("%s%13s\n","Values","Frequency");
                                       for(i=1;i<=6;i++) {
                                         printf("%d\t%10d\n",i,sayac[i]);
                                         }
                                         getch();
                                         return 0;
}
