#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
main()
{
      char i;
      
      for(i='A';i<='z';i++)
      printf("%c\t%d\n",i,i);
      
      getch ();
      return 0;
      }
